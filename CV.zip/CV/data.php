<?php

$biodatas = [
    'Much. Rafid Syakir',
    'perum magersari blok at 09',
    'SMKN 2 Buduran',
    'img/rapid.jpg',
    'img/rapid2.jpg',
    'Software Engineer',
    'Sidoarjo 30/Desember/2008'
];

$skills = [
    'Bermain game',
    'Olahraga',
    'Matematika',
];

$hobbies = [
    'Renang',
    'Sepak bola',
    'Badminton',
];

$studies = [
    "Mi ma'arif pagerwojo",
    ' Smpn 2 sidoarjo',
    'Smkn 2 buduran',
];
